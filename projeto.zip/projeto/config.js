var config={
    database:{
        host:'localhost',
        user :'root',
        password:'rootmarciABo@3A',
        database:'blog'
    }
}
module.exports=config;